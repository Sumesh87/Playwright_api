
export class EnvManager {
  static getBaseURL(): string {
    const env = process.env.ENV || 'GQA';
    switch (env) {
      case 'GRC':
        return 'https://grc.api.example.com';
      case 'GQA':
        return 'https://gqa.api.example.com';
      default:
        throw new Error(`Unknown ENV: ${env}`);
    }
  }
}
