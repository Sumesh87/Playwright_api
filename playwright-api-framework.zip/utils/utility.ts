
export class Utility {
  static extractValueFromPath(json: any, path: string): any {
    return path.split('.').reduce((acc, key) => acc?.[key], json);
  }

  static mathValue(op: string, value: number): number {
    switch (op) {
      case 'divide-by-2': return value / 2;
      default: return value;
    }
  }

  static expectedValues(actual: any, expected: any, msg: string) {
    if (actual === expected) {
      console.log(`✅ ${msg}`);
    } else {
      console.error(`❌ Mismatch: expected ${expected}, got ${actual}`);
    }
  }
}
