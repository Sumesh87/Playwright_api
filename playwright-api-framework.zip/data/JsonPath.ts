
export const JsonPath = {
  gIncome_SubF: 'subf.grossIncome',
  eIncome_SubF: 'subf.effectiveIncome',
  sIncome_SubF: 'subf.subpartIncome',
  gIncome_scheI1: 'scheduleI1.grossIncome',
  sIncome_scheI1: 'scheduleI1.subPartIncome',
  tIncome_scheI1: 'scheduleI1.testedIncome'
};
