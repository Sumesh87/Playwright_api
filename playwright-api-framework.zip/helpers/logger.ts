
export class Logger {
  static async logResponse(endpoint: string, response: any): Promise<void> {
    console.log(`\n[${endpoint}] => Status: ${response.status()}`);
    const body = await response.text();
    console.log(`[${endpoint}] => Body: ${body}`);
  }
}
