
import { APIRequestContext, request } from '@playwright/test';
import { RequestBuilder } from '../builders/requestBuilder';

export class ApiHelper {
  static async sendRequest(baseURL: string, builder: RequestBuilder) {
    const context = await request.newContext({ baseURL });
    const options = builder.build();
    const method = options.method || 'GET';
    return await context.fetch(options.url, { method, headers: options.headers, data: options.data });
  }
}
