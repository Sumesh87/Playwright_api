
import fs from 'fs/promises';

export class TokenHelper {
  static async getAccessToken(path: string): Promise<string> {
    const raw = await fs.readFile(path, 'utf-8');
    const parsed = JSON.parse(raw);
    return parsed?.accessToken || parsed?.token || '';
  }
}
