
export class RequestBuilder {
  private methodVal: string = 'GET';
  private urlVal: string = '';
  private headersVal: Record<string, string> = { 'Content-Type': 'application/json' };
  private dataVal: any = null;

  withMethod(method: string): RequestBuilder {
    this.methodVal = method;
    return this;
  }

  withURL(url: string): RequestBuilder {
    this.urlVal = url;
    return this;
  }

  withHeaders(headers: Record<string, string>): RequestBuilder {
    this.headersVal = { ...this.headersVal, ...headers };
    return this;
  }

  withToken(token: string): RequestBuilder {
    this.headersVal['Authorization'] = `Bearer ${token}`;
    return this;
  }

  withPayload(data: any): RequestBuilder {
    this.dataVal = data;
    return this;
  }

  build() {
    return {
      method: this.methodVal,
      url: this.urlVal,
      headers: this.headersVal,
      data: this.dataVal,
    };
  }
}
