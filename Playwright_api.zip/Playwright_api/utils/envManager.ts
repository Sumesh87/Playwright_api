export type EnvType = 'qa' | 'dev' | 'prod';

export class EnvManager {
    private static env: EnvType = (process.env.TEST_ENV as EnvType) || 'qa';

    private static config = {
        qa: { baseURL: 'https://restful-booker.herokuapp.com' },
        dev: { baseURL: 'https://dev.booker.com/api' },
        prod: { baseURL: 'https://prod.booker.com/api' }
    };

    static getBaseURL(): string {
        return this.config[this.env].baseURL;
    }

    static setEnv(env: EnvType) {
        this.env = env;
    }

    static getEnv(): EnvType {
        return this.env;
    }
}