import * as XLSX from 'xlsx';
import path from 'path';

export class ExcelReader {
    static readSheet(filePath: string, sheetName: string): any[] {
        const absolutePath = path.resolve(__dirname, '..', filePath);
        const workbook = XLSX.readFile(absolutePath);
        const sheet = workbook.Sheets[sheetName] || workbook.Sheets[workbook.SheetNames[0]];
        return XLSX.utils.sheet_to_json(sheet);
    }
}