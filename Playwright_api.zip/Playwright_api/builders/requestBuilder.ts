import type { APIRequestOptions } from '@playwright/test';
import { PayloadInterface } from '../interfaces/payloadInterface';

export class RequestBuilder {
  private options: APIRequestOptions = {
    headers: { 'Content-Type': 'application/json' },
    method: 'GET'
  };

  withHeaders(headers: Record<string, string>) {
    this.options.headers = { ...this.options.headers, ...headers };
    return this;
  }

  withBearerToken(token: string) {
    this.options.headers = { ...this.options.headers, Authorization: `Bearer ${token}` };
    return this;
  }

  withPayload(payload: PayloadInterface) {
    this.options.data = payload;
    return this;
  }

  withParams(params: Record<string, string>) {
    this.options.params = params;
    return this;
  }

  withMethod(method: 'GET'|'POST'|'PUT'|'DELETE'|'PATCH') {
    this.options.method = method;
    return this;
  }

  build(): APIRequestOptions {
    return this.options;
  }
}
