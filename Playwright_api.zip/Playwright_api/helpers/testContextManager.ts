export class TestContextManager {
  private static context: Record<string, any> = {};

  static get(key: string): any {
    return this.context[key];
  }

  static set(key: string, value: any): void {
    this.context[key] = value;
  }

  static clear(): void {
    this.context = {};
  }
}