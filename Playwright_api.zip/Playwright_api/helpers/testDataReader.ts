import xlsx from 'xlsx';
import path from 'path';

const __dirname = path.resolve();

export class TestDataReader {
  static readSheet(sheetName: string): any[] {
    const wb = xlsx.readFile(path.join(__dirname, '../data/TestData.xlsx'));
    const sheet = wb.Sheets[sheetName];
    return xlsx.utils.sheet_to_json(sheet);
  }
}
