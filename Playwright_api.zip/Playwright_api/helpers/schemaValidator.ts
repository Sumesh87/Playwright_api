export class SchemaValidator {
    static validate(body: any, schema: any) {
        const result = schema.safeParse(body);
        if (!result.success) {
            throw new Error(JSON.stringify(result.error.issues));
        }
    }
}