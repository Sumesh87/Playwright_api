import { expect } from '@playwright/test';

export class AssertionHelper {
  static async assertStatusCode(response: any, expected: number) {
    expect(response.status()).toBe(expected);
  }

  static assertHasKeys(obj: any, keys: string[]) {
    for (const k of keys) {
      expect(obj).toHaveProperty(k);
    }
  }

  static assertFieldType(obj: any, key: string, type: string) {
    expect(typeof obj[key]).toBe(type);
  }
}
