export class RetryHelper {
    static async retry(fn: Function, retries = 3, delay = 1000) {
        let lastError;
        for (let i = 0; i < retries; i++) {
            try {
                return await fn();
            } catch (error) {
                lastError = error;
                await new Promise(res => setTimeout(res, delay));
            }
        }
        throw lastError;
    }
}