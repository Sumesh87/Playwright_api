import { APIRequestContext, request } from '@playwright/test';
import { RequestBuilder } from '../builders/requestBuilder';

export class ApiHelper {
  static async sendRequest(baseURL: string, endpoint: string, builder: RequestBuilder) {
    const apiContext: APIRequestContext = await request.newContext({ baseURL });
    const response = await apiContext.fetch(endpoint, builder.build());
    return response;
  }
}
