export class Logger {
    static logResponse(endpoint: string, response: any) {
        console.log(`Response from ${endpoint}:`, response.status());
    }
}