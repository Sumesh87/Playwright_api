import { TestContextManager } from './testContextManager';

export class ChainRequestManager {
    static extractAndSave(responseBody: any, key: string, contextKey: string) {
        if (responseBody[key]) {
            TestContextManager.set(contextKey, responseBody[key]);
        }
    }
}