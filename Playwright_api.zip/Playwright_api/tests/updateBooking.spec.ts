import { test, expect } from '@playwright/test';
import { ApiHelper } from '../helpers/apiHelper';
import { RequestBuilder } from '../builders/requestBuilder';
import { Logger } from '../helpers/logger';
import { TestContextManager } from '../helpers/testContextManager';
import { EnvManager } from '../utils/envManager';

const BASE_URL = EnvManager.getBaseURL();

test.describe('Update Booking - PUT and PATCH', () => {
  let bookingId: number;

  test.beforeAll(async () => {
    const payload = {
      firstname: 'Old',
      lastname: 'Name',
      totalprice: 222,
      depositpaid: false,
      bookingdates: {
        checkin: '2024-10-01',
        checkout: '2024-10-10',
      },
      additionalneeds: 'None'
    };

    const request = new RequestBuilder().withMethod('POST').withPayload(payload);
    const response = await ApiHelper.sendRequest(BASE_URL, '/booking', request);
    const body = await response.json();
    bookingId = body.bookingid;
    TestContextManager.set('bookingId', bookingId);
  });

  test('Update full booking with PUT', async () => {
    const updatedPayload = {
      firstname: 'Updated',
      lastname: 'Name',
      totalprice: 333,
      depositpaid: true,
      bookingdates: {
        checkin: '2025-01-01',
        checkout: '2025-01-05',
      },
      additionalneeds: 'Lunch'
    };

    const builder = new RequestBuilder()
      .withMethod('PUT')
      .withPayload(updatedPayload)
      .withHeaders({
        Authorization: 'Basic YWRtaW46cGFzc3dvcmQxMjM='
      });

    const response = await ApiHelper.sendRequest(BASE_URL, `/booking/${bookingId}`, builder);
    expect(response.status()).toBe(200);
    Logger.logResponse(`/booking/${bookingId}`, response);
  });

  test('Partial update with PATCH', async () => {
    const partialPayload = { firstname: 'PatchName' };

    const builder = new RequestBuilder()
      .withMethod('PATCH')
      .withPayload(partialPayload)
      .withHeaders({
        Authorization: 'Basic YWRtaW46cGFzc3dvcmQxMjM='
      });

    const response = await ApiHelper.sendRequest(BASE_URL, `/booking/${bookingId}`, builder);
    expect(response.status()).toBe(200);
    Logger.logResponse(`/booking/${bookingId}`, response);
  });
});