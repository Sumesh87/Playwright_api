import { test, expect } from '@playwright/test';
import { RequestBuilder } from '../builders/requestBuilder';
import { ApiHelper } from '../helpers/apiHelper';
import { bookingSchema } from '../schemas/bookingSchema';
import { SchemaValidator } from '../helpers/schemaValidator';
import { Logger } from '../helpers/logger';
import { EnvManager } from '../utils/envManager';

test('POST /booking', async () => {
    const baseURL = EnvManager.getBaseURL();
    const payload = {
        firstname: "Jim",
        lastname: "Brown",
        totalprice: 111,
        depositpaid: true,
        bookingdates: {
            checkin: "2018-01-01",
            checkout: "2019-01-01"
        },
        additionalneeds: "Breakfast"
    };

    const builder = new RequestBuilder()
        .withMethod('POST')
        .withPayload(payload);

    const response = await ApiHelper.sendRequest(baseURL, '/booking', builder);
    expect(response.status()).toBe(200);
    const responseBody = await response.json();
    SchemaValidator.validate(responseBody, bookingSchema);
    Logger.logResponse('/booking', response);
});