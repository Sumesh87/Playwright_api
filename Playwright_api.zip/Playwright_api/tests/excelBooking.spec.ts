import { test, expect } from '@playwright/test';
import { RequestBuilder } from '../builders/requestBuilder';
import { ApiHelper } from '../helpers/apiHelper';
import { Logger } from '../helpers/logger';
import { EnvManager } from '../utils/envManager';
import { ExcelReader } from '../utils/excelReader';

const BASE_URL = EnvManager.getBaseURL();

test('Data-driven booking tests from Excel', async () => {
    const testData = ExcelReader.readSheet('data/bookingTestData.xlsx', 'Sheet1');

    for (const data of testData) {
        const payload = {
            firstname: data.firstname,
            lastname: data.lastname,
            totalprice: data.totalprice,
            depositpaid: data.depositpaid,
            bookingdates: {
                checkin: data.checkin,
                checkout: data.checkout
            },
            additionalneeds: data.additionalneeds
        };

        const builder = new RequestBuilder().withMethod('POST').withPayload(payload);
        const response = await ApiHelper.sendRequest(BASE_URL, '/booking', builder);
        expect(response.status()).toBe(200);
        Logger.logResponse('/booking', response);
    }
});