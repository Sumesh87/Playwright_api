import { test } from '@playwright/test';
import { ApiHelper } from '../helpers/apiHelper';
import { RequestBuilder } from '../builders/requestBuilder';
import { RetryHelper } from '../helpers/retryHelper';
import { Logger } from '../helpers/logger';
import { SchemaValidator } from '../helpers/schemaValidator';
import { ChainRequestManager } from '../helpers/chainRequestManager';
import { TestContextManager } from '../helpers/testContextManager';
import { TestDataReader } from '../helpers/testDataReader';
import { bookingSchema } from '../schemas/bookingSchema';

const BASE_URL = 'https://restful-booker.herokuapp.com';

test.describe('Excel-driven booking tests', () => {
  const rows = TestDataReader.readSheet('CreateBooking');

  for (const row of rows) {
    test(`${row.TestCaseID} – create booking for ${row.firstname}`, async () => {
      TestContextManager.clear();

      const payload = {
        firstname: row.firstname,
        lastname: row.lastname,
        totalprice: Number(row.totalprice),
        depositpaid: row.depositpaid === 'true',
        bookingdates: {
          checkin: row.checkin,
          checkout: row.checkout
        },
        additionalneeds: row.additionalneeds
      };

      const request = new RequestBuilder()
        .withMethod('POST')
        .withPayload(payload);

      const response = await RetryHelper.retry(() =>
        ApiHelper.sendRequest(BASE_URL, '/booking', request), 3, 1500);

      Logger.logResponse('/booking', response);
      await SchemaValidator.validate(await response.json(), bookingSchema);

      // save bookingid to context
      const body = await response.json();
      ChainRequestManager.extractAndSave(body, 'bookingid', 'bookingId');
      console.log('Saved bookingId:', TestContextManager.get('bookingId'));
    });
  }
});
