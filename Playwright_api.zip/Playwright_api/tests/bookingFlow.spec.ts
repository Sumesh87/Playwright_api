import { test, expect } from '@playwright/test';
import { ApiHelper } from '../helpers/apiHelper';
import { RequestBuilder } from '../builders/requestBuilder';
import { RetryHelper } from '../helpers/retryHelper';
import { Logger } from '../helpers/logger';
import { SchemaValidator } from '../helpers/schemaValidator';
import { ChainRequestManager } from '../helpers/chainRequestManager';
import { TestContextManager } from '../helpers/testContextManager';
import { bookingSchema } from '../schemas/bookingSchema';
import { EnvManager } from '../utils/envManager';

const BASE_URL = EnvManager.getBaseURL();

test.describe('Booking Flow - POST, GET, DELETE', () => {
  let bookingId: number;

  test('Create Booking [POST]', async () => {
    const payload = {
      firstname: 'Jim',
      lastname: 'Brown',
      totalprice: 111,
      depositpaid: true,
      bookingdates: {
        checkin: '2018-01-01',
        checkout: '2019-01-01',
      },
      additionalneeds: 'Breakfast',
    };

    const builder = new RequestBuilder().withMethod('POST').withPayload(payload);
    const response = await RetryHelper.retry(() => ApiHelper.sendRequest(BASE_URL, '/booking', builder));
    expect(response.status()).toBe(200);
    const body = await response.json();
    Logger.logResponse('/booking', response);
    SchemaValidator.validate(body, bookingSchema);
    ChainRequestManager.extractAndSave(body, 'bookingid', 'bookingId');
    bookingId = TestContextManager.get('bookingId');
  });

  test('Get Booking [GET]', async () => {
    const id = TestContextManager.get('bookingId');
    const builder = new RequestBuilder().withMethod('GET');
    const response = await RetryHelper.retry(() => ApiHelper.sendRequest(BASE_URL, `/booking/${id}`, builder));
    expect(response.status()).toBe(200);
    Logger.logResponse(`/booking/${id}`, response);
  });

  test('Delete Booking [DELETE]', async () => {
    const id = TestContextManager.get('bookingId');
    const builder = new RequestBuilder().withMethod('DELETE').withHeaders({
      Authorization: 'Basic YWRtaW46cGFzc3dvcmQxMjM='
    });
    const response = await ApiHelper.sendRequest(BASE_URL, `/booking/${id}`, builder);
    Logger.logResponse(`/booking/${id}`, response);
    expect([200, 201, 204]).toContain(response.status());
  });
});